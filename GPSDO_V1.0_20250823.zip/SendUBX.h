

#pragma once
#include "PrintHEX.h"
#include "getUBX_ACK.h"


namespace SendUBX 
{
    bool ackBack = false;    
    // tries sending UBX data 5 times and if acked within 3 seconds return true else false
    bool sendUBXBuf(uint8_t *MSG, uint8_t len){
    for (int x = 0; x < 5; x++){
        for(int i=0; i<len; i++) {
            Serial1.write(MSG[i]);
         //   if ( i % 10 == 0 && i != 0) debug("\n") ;
         //   PrintHEX::PrnHEX(MSG[i]);   // Print Hex Chars nicely
          }
        ackBack = getUBX_ACK::get_ACK(MSG);   // look for ACK
        if (ackBack == true)
            return true;                      // returns true after 1 seconds max
            debug("Trying times = %d \n");
       }
       return false;  // tried 5 times and failed 
    } 
}