

#pragma once

namespace PrintHEX
  {
      // Print Hex Chars nicely. 
  void PrnHEX(uint8_t MyChr) {  
      debug("0x");
      debug(MyChr < 16 ? "0" : "");
      debug("%s %x ", MyChr, HEX);
      debug(" ");      
  } 
}