/*
  Sets the position of the frequency underscore.
*/

#pragma once

namespace underScore
{
   void set( )
   {
    // moving the underscore
    underscorePosition++;
    if (underscorePosition > 8)
      underscorePosition = 0;           
    debug("16 Underscore Position is %d \n", underscorePosition);
    OLED::underScore(underscorePosition);  // set the new underscore position
   }
}