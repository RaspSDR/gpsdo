

#pragma once


namespace setDivider
{
   void set(int outPin, int inPin)
   {
      // This code sets up the Pico PWM to divide the 10 MHz clock on GPIO 21 by 10 or 100 and outputs on GPIO 20.
        // Set GPIO20 pin to PWM output (channel A)
        gpio_set_function(outPin, GPIO_FUNC_PWM);
        // Set GPIO21 pin to PWM input (channel B)
        gpio_set_function(inPin, GPIO_FUNC_PWM);
        // Get the PWM slice for the pin
        uint slice_num = pwm_gpio_to_slice_num(outPin);   // This is the output pin number
        // Enable PWM
        pwm_set_enabled(slice_num, true);
        // Set Channel B be the PWM counter clock
        pwm_set_clkdiv_mode(slice_num, PWM_DIV_B_RISING); 
        // Set clock divider (use 1 for 1 MHz and 10 for 100kHz and  100 for 10kHz). Max 256.0 (8 integer bit and 4 fractional bit)
        pwm_set_clkdiv_int_frac(slice_num, 10, 0);    
        // Set counter maximum value before wrap (max 65535)
        pwm_set_wrap(slice_num, 9);
        // Set pulse length in ref clock cycles after division 
        pwm_set_chan_level(slice_num, PWM_CHAN_A, 5);
   }  
}