/*
  shows error and stays here!
*/

#pragma once


namespace show
{

  void error(int speed, bool graphic){
    // Shows error screen if graphic selected then displays "Can't access GPS serial port, Try power recycle "
    if (graphic)
        OLED::error();
    while(true){
      setLED::set("red");
      delay(speed);
      setLED::clear();
      delay(speed);
    }
  }
}
 