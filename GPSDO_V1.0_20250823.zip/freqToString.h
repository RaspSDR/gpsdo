/*
  Converts an integer frequency into the required string format
  For the frequency screen then all parts have a 0, for the main screen leading 0's are not displayed.

 */

 #pragma once     

 // no globals

namespace freqToString{

long frequency;
int length = 0;
String done;
String stringFreq;

// get the length of the frequency
int howLong(int frequency){
  debug("frequency integer = %d \n", frequency);
  // convert to a string
  String stringFreq = String(frequency);
  length = stringFreq.length();
  return length;
}
 
// convert code here 
String convert (long frequency, bool screenType){

 debug("screenType = %d \n", screenType); 

debug("frequency integer = %d \n", frequency);
String stringFreq = String(frequency);
length = stringFreq.length();

debug("stringFreq is = %s\n", stringFreq.c_str());
debug("string length is =  %d\n", length);


// buffer to store the char array in.
char buffer[length + 1];
// convert to char array
stringFreq.toCharArray(buffer, length + 1);
debug("buffer contains the folowing %s\n ", String(buffer));


// the '\0' at the end of the result is to show end of a string. buffer[0] is the higest frequency digit
// If screen is true then the string will be written for use on the frequency display. If not then the main screen.
if (screenType){  
    if (length == 9){
        char result[] = {buffer[0], buffer[1], buffer[2], '.', buffer[3], buffer[4], buffer[5], '.',buffer[6], buffer[7], buffer[8], '\0' };
        done = result;
      }
      else if (length == 8){
        char result[] = {'0', buffer[0], buffer[1], '.', buffer[2], buffer[3], buffer[4], '.',buffer[5], buffer[6], buffer[7], '\0'};
        done = result;
    }
    else if (length == 7){
        char result[]= {'0','0', buffer[0], '.', buffer[1], buffer[2], buffer[3], '.',buffer[4], buffer[5], buffer[6], '\0'};
        done = result;      
    }
    else if (length == 6){
        char result[] = {'0', '0', '0', '.', buffer[0], buffer[1], buffer[2],'.', buffer[3], buffer[4], buffer[5], '\0'};
        done = result;
    }
    else if (length == 5){
        char result[] = {'0', '0', '0', '.', '0', buffer[0], buffer[1],'.', buffer[2], buffer[3], buffer[4], '\0'};
        done = result;
     }
    else if (length == 4){
        char result[] = {'0', '0', '0', '.', '0', '0', buffer[0], '.', buffer[1], buffer[2], buffer[3], '\0'};
        done = result;
    }
    else if (length == 3){
        char result[] = {'0', '0', '0', '.', '0', '0', '0', '.',  buffer[0], buffer[1], buffer[2], '\0'};
        done = result;
    }
    else if (length == 2){
        char result[] = {'0', '0', '0', '.', '0', '0', '0', '.', '0', buffer[0], buffer[1], '\0'};
        done = result;
    }
    else if (length == 1){
        char result[] = {'0', '0', '0', '.', '0', '0', '0', '.', '0', '0', buffer[0], '\0'};
        done = result;
    }
  }

// This is used if the main screen is selected.
else {
    if (length == 9){
      char result[] = {buffer[0], buffer[1], buffer[2], '.', buffer[3], buffer[4], buffer[5], '.',buffer[6], buffer[7], buffer[8], '\0' };
      done = result;
    }
else if (length == 8){
     char result[] = {buffer[0], buffer[1], '.', buffer[2], buffer[3], buffer[4], '.',buffer[5], buffer[6], buffer[7], '\0'};
     done = result;
    }
else if (length == 7){
    char result[]= { buffer[0], '.', buffer[1], buffer[2], buffer[3], '.',buffer[4], buffer[5], buffer[6], '\0'};
    done = result;
    }
else if (length == 6){
    char result[] = {buffer[0], buffer[1], buffer[2],'.', buffer[3], buffer[4], buffer[5], '\0'};
    done = result;
    }
else if (length == 5){
    char result[] = {buffer[0], buffer[1],'.', buffer[2], buffer[3], buffer[4], '\0'};
    done = result; 
   } 
else if (length == 4){
    char result[] = {buffer[0], '.', buffer[1], buffer[2], buffer[3], '\0'};
    done = result;
    }  
else if (length == 3){
    char result[] = {buffer[0], buffer[1], buffer[2], '\0'};
    done = result;
    }  
else if (length == 2){
    char result[] = {buffer[0], buffer[1], '\0'};
    done = result;
    }
else if (length == 1){
    char result[] = {buffer[0], '\0'};
    done = result; 
    } 
 }

 //debug("final frequency = %d\n ", String(done));
 
  return (String(done));

  } // end of convert
 }  // end of namespace