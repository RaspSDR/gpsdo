/*
  Reads voltage from ADC0 which is the OCXO control voltage multiplied by 0.66
   5.0 v = 4095  hence calibration is  5.0/4095 = 0.001221

  If Vc < x or > x then padlock is shown with an X over it 
  since the PLL will not be locked.

  Locked status shown after 3 consecutive readings.
  
  Averages every second and returns as a string containing Vc.

*/

#include "device/usbd.h"  // reqired to get ADC A0 value

#pragma once

float Vc = 500.00f;
float previous = 0.00f;
float actual = 0.00f;
int y = 0;
int z = 0;

namespace VcVoltage
{
  String volts()
  {
    Vc = Vc + 0.3 * (analogRead(A0) - previous);  // create an average
    // show locked padlock if delta is too big 3 consecutive times or unlocked if not
    if (Vc > previous + 80 || Vc < previous - 80)
        y++;
    else
        z++;
    if ( y >= 2) {                   
      OLED::showLock(true);   // show padlock with X on it. 
      y = 0;                    
    }
    else if (z >= 2 ){
      OLED::showLock(false);  //show padlock without X
      z = 0;
    }
    
    previous = Vc;
    actual = Vc * 0.001221;
    return String(actual,1);    // only use 1 decimal point
  }
}

