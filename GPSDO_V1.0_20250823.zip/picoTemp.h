/*
  Shows Pico temperature.  Very unstable so use average function.
*/

#pragma once


namespace picoTemp
{
  float Temp;
  float tempNow = 25;
  float previous = 0;

  String get(){
    Temp =  analogReadTemp();
    tempNow = tempNow + 0.1 * (Temp - previous); // average temp
    previous = tempNow;
    return String(tempNow,0);   // convert to a string with no decimal places
  }
}