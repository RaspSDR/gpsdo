



#pragma once

int underscorePosition = 0;

namespace freqSetup
{

  void now(long unsigned &frequency) {

    debug("Button was pressed > 1 second so moving to frequency mode\n");
    // display the basic frequency screen
    // Set up the OLED, clear the screen
    OLED::setup();
    // get the frequency saved in the EEPROM 
    frequency = EEPROMFrequency::read();
    // display EEPROM frequency
    OLED::show(frequency, true);
    // put an underscore on digit 0 and display it
    underscorePosition = 0;
    OLED::underScore(underscorePosition);
  }
}