

#pragma once

#include <Arduino.h>

class Si5351 {

public:
  // Constructor
  void begin(uint32_t reference);
  // Methods
  void WriteRegister(uint8_t regAddr, uint8_t data);
  uint8_t ReadRegister(uint8_t regAddr);
  void CalcRegisters(const uint32_t fout, uint8_t *regs);
  void setOutput(unsigned long frequency);

private:
};