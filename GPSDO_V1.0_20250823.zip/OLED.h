/*
  This displays the startup screen and increments the bar from the value sent.
  It also displays the frequency components.
*/

#pragma once

#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h> // use version 2.5.11 now
#include "graphics.h"
#include <Fonts/FreeSans9pt7b.h>  // Change from standard font since else too small
#include "freqToString.h"
#define SCREEN_WIDTH 128      // OLED display width, in pixels
#define SCREEN_HEIGHT 64      // OLED display height, in pixels
#define  barLength  0

// Declaration for an SSD1306 display connected to I2C (SDA, SCL pins) and set I2C at 400kHz during and after use. 
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1, 400000, 400000);

int length = 0;
int setFrequencyPosition[] = {0, 80, 74, 68, 0, 56, 50, 44, 0, 32, 26, 20};

namespace OLED
{
  // check that the OLED is working 
  bool check(){
    if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
        return false;
      }
    else 
        return true;
  }

  void start(){  
    // display the startup screen, world graphic and "Setting up"
    display.setFont(); 
    display.clearDisplay(); 
    // display world icon 
    display.drawBitmap(0, 0, graphics::world_image, 62, 64, 1);
    // add 'Setting up" text and empty bar
    display.setTextSize(1);
    display.setTextColor(WHITE);        //  had to add this!
    display.setCursor(63, 3);
    display.print("Setting up");
    display.drawRect(56, 49, 58, 12, 1);
    display.display();
    }

  // setup the OLED for the frequency display
  void setup(){
    display.clearDisplay();
    display.setFont(&FreeSans9pt7b);    // set the font
    display.setTextSize(1);
    display.setTextColor(WHITE);        // set items displayed to be white
    display.display();
  }


  // Fill the bar graph to the length sent
  void fill(int length){
    display.fillRect(57,50, length * 8, 10, 1 );
    display.display();
  }  
  // show thumb up
  void thumb(){
    display.drawBitmap(83, 21, graphics::thumb_image, 16, 16, 1);
    display.display();
  }
   // shows satellite icon and "Finding Satellites"
   void search(){
    display.setFont(); 
    display.clearDisplay(); 
    // display satellite icon 
    display.drawBitmap(0, 0, graphics::satellite_image, 62, 64, 1);
    // display text "Finding Satellites"
    display.setTextColor(WHITE);        
    display.setCursor(63, 3);
    display.print("Finding");
    display.setCursor(63, 12);
    display.print("Satellites");
    display.display();
   }
   // show number of satellites found in large font
   void satNumber(int number){
    // remove previous value using black rectangle for 2 digits!
    display.fillRect(82, 24, 28, 18, BLACK);
    display.setTextSize(2);
    display.setTextColor(WHITE);        
    display.setCursor(85, 26);
    display.print(String(number));
    display.display();
   }
   // show Satellite waiting bar graph
   void waiting(int length){
    display.drawRect(60, 49, 62, 12, 1);
    display.fillRect(61,50, length, 10, WHITE );
    display.display();
   }
   // clear Satellite waiting bar graph
   void waitingClear(){
    display.fillRect(61,50, 60, 10, BLACK);
   }

   // Clear area then send "No GPS found. Check antenna and location"
   void noGPS(){
    // clear the area first
    display.fillRect(51, 24, 77, 38, BLACK);
    display.setTextSize(1);
    display.setTextColor(WHITE); 
    display.setCursor(48, 29);
    display.print("Not enough!");
    display.setCursor(48, 39);
    display.print("Check antenna");
    display.setCursor(48, 50);
    display.print("and location");
    display.display();
   }

  // clear the No GPS message
   void noGPSClear(){
    display.fillRect(48, 24, 77, 38, BLACK);
   }
   
  // Sets 'UTC', 'v', '0C',  and 'Sats'
   void main(){
    display.clearDisplay(); 
    display.setFont(); 
    display.setTextColor(WHITE);
    display.setTextSize(1);
    display.setTextWrap(true);
    display.setCursor(55, 7);
    display.print("UTC");                   // display UTC
    display.drawCircle(115, 3, 2, WHITE);   // draw a small circle before the C
    display.setCursor(119, 2);
    display.print("C");                     // display C
    display.setCursor(83, 53);
    display.print("Sats");                  // display Sats
    display.setCursor(22, 2);
    display.print("v");                     // display v
   }


  // Sets the clock time
  void time(String time){
    // clear current time
    display.fillRect(15, 16, 98, 19, BLACK);
    display.setTextSize(2);
    display.setCursor(17, 18);
    display.print(time);
    display.display();
    display.setTextSize(1);    
  }

  // Displays number of satellites bottom RHS
  void numberSats(int number){
    // clear current number
    display.fillRect(107, 52, 15, 9, BLACK);
    display.setCursor(109, 53);
    display.setTextSize(1);
    display.print(String (number));
    display.display();
  }

    // show error screen
  void error(){          
    display.clearDisplay();
    display.setTextColor(WHITE);
    display.setTextSize(1);
    display.setCursor(5, 2);
    display.print("Error!");
    display.setCursor(5, 13);
    display.print("Can't access GPS");
    display.setCursor(5, 25);
    display.print("Serial Port.");
    display.setCursor(6, 37);
    display.print("Try power recycle.");
    display.display();
  }

  // show Vc
  void volts(String vs){
    display.setTextSize(1);
    display.fillRect(2,1,19,10, BLACK);    // clear any previous data
    display.setCursor(2, 2);
    display.print(vs);                     // display the Vc voltage
    display.display();
  }

  // show Pico temperature
  void temp(String temp){
    display.setTextSize(1);
    display.fillRect(100,1,12,9, BLACK);    // clear previous temperature
    display.setCursor(101, 2);
    display.print(temp);                    // display the temperature
    display.display();
    }

  // show lock with either cross or not
  void showLock(bool cross){
    // clear the current padlock
    display.fillRect(3,45,17,62, BLACK);
    // show the padlock
    display.drawBitmap(3, 45, graphics::locked_image, 13, 16, 1);
    // if cross true then show it
    if (cross){
      display.drawLine(15,45,3,61, WHITE);
      display.drawLine(3,45,16,61, WHITE);
    }
    display.display();
  }


  // converts frequency to a string then displays on OLED at position depending on its length.
  // screenType if true selects frequency screen format and if false main screen 
 void show(int frequency, bool screenType){
   String OLEDFreq = freqToString::convert(frequency, screenType);  // convert the integer frequency to a string with '.' in it and zeros if required
     if (screenType) {
      debug("218 ScreenType = %s, OLED Frequency length (1 to 11) = %d, OLED frequency = %s \n", screenType  ? "freqScreen" : "mainScreen", length, OLEDFreq.c_str() );
      display.fillRect(5, 23, 103, 15, BLACK);
      display.setFont(&FreeSans9pt7b);  // set frequency font 
      display.setCursor(5, 36);         // normally 5 with 11 digits 
      display.print(OLEDFreq);          // display the formatted frequency
      // Display MHz, kHz or Hz
      display.setFont();                // set to default
      // clear existing frequency type
      display.fillRect(107, 27, 125, 8, BLACK);
      display.setCursor(108, 28); 
      length = freqToString::howLong(frequency);
      if (length > 6)
            display.print("MHz");
      else if (length > 3)
            display.print("kHz");
      else 
            display.print(" Hz");     

      display.setFont(&FreeSans9pt7b);  // restore previous font
    }
    else {
      debug("showing frequency in small font\n");
      // clear the current frequency displayed
      display.setFont();                // set the main font
      display.fillRect(89, 34, 19, 10, BLACK);
      // display the frequency if not 0
      if (frequency != 0){
        length = OLEDFreq.length();  // get its length
        debug("246 ScreenType = %s, OLED Frequency length (1 to 11) = %d \nOLED frequency = %s \n", screenType  ? "freqScreen" : "mainScreen", length, OLEDFreq.c_str() );
        debug("setFrequencyPosition = %d \n",setFrequencyPosition[length]);
        display.setCursor(setFrequencyPosition[length], 36);
        display.print(OLEDFreq);      // display the formatted frequency
        // Display MHz or kHz
        display.setCursor(90, 36); 
        if (length > 7)
              display.print("MHz");
        else display.print("kHz");
      }
    }
    // display the frequency
    display.display();
 }


  void freqSaved(){
    // display "Frequency Saved" on OLED
    display.setFont();                // sets to default Adafruit 5x7
    display.setCursor(11, 10);
    display.print("Frequency Saved");
    display.display();
    delay(1000);
  }

  void wrong(bool error){
    display.setFont();                // sets to default Adafruit 5x7
    display.setCursor(11, 10);
    if (error)
       display.print("Error > 160MHz");
    else
       display.print("Error < 8kHz");
    display.display();
    display.setFont(&FreeSans9pt7b);  // restore previous font
    delay(3000);
    display.fillRect(9, 7, 104, 12, BLACK);
    display.display();
  }

void underScore(int digit) {
  int y = 40;  // y position of underscore

  int x[] = { 96, 86, 76, 61, 51, 41, 26, 16, 6 };  // x positions of underscore

  int setX = x[digit];
  // clear previous line with a black filled rectangle
  display.fillRect(5, 38, 106, 5, BLACK);
  // draw the under score
  display.drawLine(setX, y, setX + 7, y, 1);
  display.display();
  }


 }