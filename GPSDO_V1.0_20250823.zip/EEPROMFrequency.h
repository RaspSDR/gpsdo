/*
  How to use the EEPROM of the RP2040  and save a frequency in it.

  If the EEPROM is clear then each address returns 0xFF.
 
*/


 #pragma once     

 // no globals

namespace EEPROMFrequency {

// convert the frequency into 4 bytes
  union {
      unsigned long frequency;
      unsigned char bytes[4];
  } intToByte;

long value;

long  read() {
  // read what is currently in the EEPROM
    debug("This is what's currently in the EEPROM \n");
    for (int x = 0; x < 4; x++) {
     value = EEPROM.read(x);     
     debug("  %d  %X \n", x, value);
    }

    // if all the 4 EEPROM addresses contain 0xFF or 0  then there is no frequency available
    int count = 0;
    for (int x = 0; x < 4; x++) {   
        if(EEPROM.read(x) == 0xFF | EEPROM.read(x) == 0)
          ++count;
    }
    if (count == 4)
       value = 0; 
    else {
      // now read from EEPROM and convert to long integer
      value = (unsigned long)(EEPROM.read(3) << 24 | EEPROM.read(2) << 16 | EEPROM.read(1) << 8 | EEPROM.read(0));
      debug(" Saved frequency %d  = \n", value);
    }
  return value;
  }

// save in EEPROM
void save(long frequency){
    // first convert into 4 bytes
    intToByte.frequency = frequency;
    // Place data in the EEPROM
    for (int x = 0; x < 4; x++)
      EEPROM.write(x, intToByte.bytes[x]);
    // Now save it
    EEPROM.commit();
  }
}


