


#pragma once

#include <RotaryEncoder.h>  // by Matthias Hertel

#define A 7
#define B 6

static int pos = 0;
int rotate = 0;

//set up amount to multiply the frequency based on the underscore location held in underscorePosition
long multiply[] = { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000 };

// Setup a RotaryEncoder with 4 steps per latch for the 2 signal input pins:
RotaryEncoder encoder(A, B, RotaryEncoder::LatchMode::FOUR3);

// Setup Si5351
Si5351 si5351;  // name for class of Si5351


namespace freqLoop
{

  void now(long unsigned &frequency) {
        // check for rotary moved
        encoder.tick();
        int newPos = encoder.getPosition();
        if (pos != newPos) {
          if ((int)encoder.getDirection() == 1)
            rotate = -1;
          else
            rotate = 1;

          debug("rotate  = %d \n", rotate);
          // get the new frequency, rotate determines if increased or decreased and multiply gives the magnitude to use
          // if the frequency is 0 Hz then don't allow the frequency to be set lower or sent to the Si5351
          if (frequency == 0 & rotate == -1)
           frequency = 0;
          else {
            frequency += rotate * multiply[underscorePosition];
            // If the frequency is > 160MHz then set it to 160MHz
            if (frequency > 160000000) {              
              // show red LED
              setLED::set("red");
              OLED::wrong(true);          // displays wrong frequency for 3 seconds then stays in this loop.
              setLED::set("green");
              frequency = 160000000;      // correct frequency 
            } 
          }
          // display the frequency
          OLED::show(frequency, true);
          debug("Now frequency = %d \n", frequency);

          // set Si5351 frequency if not 0 
          if (frequency != 0)
            si5351.setOutput(frequency);

          int howLong  = freqToString::howLong(frequency);  // determine how long the new frequency is
          debug("After frequency change, howLong =  %d \n", howLong);
          debug("underscore position = %d (0 to 8)\n", underscorePosition);

          // unless a digit is removed then the underscore stays under the digit,
          if (howLong == underscorePosition) {
            underscorePosition -= 1;
            OLED::underScore(underscorePosition);
        }
        // if a digit is removed and a digit(s) below that are 0 then underscore is moved
        // to the next non 0 digit or the first digit if all digits below are 0.
          if (howLong < underscorePosition) {
            underscorePosition = howLong - 1;
            OLED::underScore(underscorePosition);
          }
          // display new frequency on OLED in frequency mode
             OLED::show(frequency, true);

          pos = newPos;
        }
  }
}
