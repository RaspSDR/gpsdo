/*
  Check if the button is pressed and if < or > 1 second

*/

#pragma once

namespace pressed
{

  int button = 8;
  // returns 0 if button not pressed, 1 if < 1 second and 2 if > 1 second
  int low ()
  {

    if (digitalRead(button) == 0) {
        // debounce for 50 mS
        delay(50); 
        unsigned long now = millis();
        debug("Button is low\n");
        while (digitalRead(button) == 0);
        unsigned long length = millis() - now;
        debug("Button was pressed for %d mS\n", length);
        if (length > 1000)
          return 2;
        else
          return 1;
        }
    else return 0;
  }
}

