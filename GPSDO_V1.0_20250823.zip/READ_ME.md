
GPSDO_PICO_V1.0  26 November 2024

IMPORTANT: When compiling the code ensure that the Raspberry Pi Pico/RP2040/RP2350 is selected as tbe board.
If Raspberry Pi Pico - Arduino Mbed OS RP2040 Board is selected then compile errors will occur.

The following libraries need to be installed, the version I used during coding are as follows:

#include <RotaryEncoder.h>     // by Matthias Hertel v1.5.3
#include <Adafruit_GFX.h>      // v1.11.11
#include <Adafruit_SSD1306.h>  // v2.5.13
#include <Adafruit_NeoPixel.h> // v1.12.3

23 August 2025
A number of users have found the following vesions work:

#include <Adafruit_GFX.h>       //  v1.12.1
#include <Adafruit_SSD1306.h>   //  v2.5.15
#include <Adafruit_NeoPixel.h>  //  v1.15.1







