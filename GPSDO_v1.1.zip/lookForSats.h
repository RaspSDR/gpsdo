
/*
  Code looks for satellites for 2 minutes and if none found
  gives a warning for 4 seconds then loops.
  GPS needs at least 3 satellites for it to lock is PLL.

  If all OK then shows the clock screen.
*/

#pragma once

#include "OLED.h"
#include "getGPSData.h"

int satNumber = 0;

namespace lookForSats
{
  
  void search(){

       String Time = "**:**:**";

      // Loop until we have enough satellites, if not show a warning then look again.
      // Show the Finding Satellites image.
      OLED::search();
      // clear Satellite waiting bar graph
      OLED::waitingClear();
      //  A loop to wait until we have enough satellites, if not show a warning after 2 minutes
      while (true){
      // show Satellite waiting bar graph, 61 max.  Allow search for 124 seconds then show error. 
      for (int x = 0; x < 124; x++){
          OLED::waiting(x/2);                    // show satellite waiting  bar graph
          getGPSData::sats(satNumber, Time);     // get current number of Satellites  every second
          OLED::satNumber(satNumber);            // display current number of Satellites found, large font.
          if (satNumber > 2){
            // have enough satellites so show the number theh after 1 second show clock screen and add Time and number of Satellites
            OLED::satNumber(satNumber);           // display current number of Satellites found
            delay(1000);
            OLED::clock();
            OLED::time(Time);
            OLED::numberSats(satNumber);          // bottom RHS
            return; 
          }      
          if (x == 123 )  { 
            x = 0;                                // tried for 2 minutes so show a message then try again.
            OLED::noGPS();                        // show no GPS satellites message for 4 seconds
            delay(4000);
            OLED::search();                       // show the Finding Satellites image
            OLED::waitingClear();                 // clear Satellite waiting bar graph
          }    
        } 
      } // end while
  } // end search
} // end namespace




