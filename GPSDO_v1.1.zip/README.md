V1.0

To compile the code use Arduino IDE (2.3.2 was used). Select Raspberry Pi Pico as the Board to use.

When loading the SSD1306 library use Adafruit SSD1306 v 2.5.1 since later versions give compile errors.

V1.1

When > 2 GPS satellites have been found show the number and wait for 1 second before progressing
