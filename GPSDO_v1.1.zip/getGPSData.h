
 /*
    Gets the number of satellites and time from:
    $GPGGA,012211.00,3154.27031,S,11545.70944,E,1,06,1.15,26.3,M,-30.8,M,,*5C
              +                                   +
              |                                   |
             time                                sats 

    Converts satellite number to integer and time into HH:MM:SS  format
 */

#pragma once

 namespace getGPSData {

  String str = "";
  const char separator = ',';
  int dataLength = 0;
  char conTime [6];
  int sizeTime = 7;

  void sats(int &satNumber, String &Time){

      // clear the serial buffer else can get 0 satellites shown
      while (Serial1.available())
         Serial1.read();

      // if waiting for GPS data > 1.5 seconds show error screen
      str = Serial1.readStringUntil('\n');
      if (str == NULL){
        OLED::error();                      // has timeout so show error message and halt
        while (true);
      }

      dataLength = str.length();
      String data[dataLength];
      // split the data into an array separated by ','
      // [1] contains the time and [7] number of satellites
      for ( int i = 0; i < dataLength; i++)
      {
        int index = str.indexOf(separator);   // find the first '.'
        data[i] = str.substring(0,index);     // put the string into the data array
        str = str.substring(index + 1);       // remove this string and look for the next ','
      }

      // Convert numer of satellites to integer
      satNumber = data[7].toInt();            // this is returned since & used

      // convert time into required format HH:MM:SS
      data[1].toCharArray(conTime, sizeTime);

      Time = "";                              // clear previous time

      Time += conTime[0]; Time += conTime[1]; Time += ":";
      Time += conTime[2]; Time += conTime[3]; Time += ":";
      Time += conTime[4]; Time += conTime[5];
    }   
 }
