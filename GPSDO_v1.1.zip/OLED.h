/*
  This displays the required information on the OLED display.

*/

#pragma once

#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h> // Use version 2.5.1 else gives a compile error.
#include "graphics.h"
#define SCREEN_WIDTH 128 // OLED display width, in pixels
#define SCREEN_HEIGHT 64 // OLED display height, in pixels
#define  barLength  0

// Declaration for an SSD1306 display connected to I2C (SDA, SCL pins)
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

namespace OLED
{
  // check that the OLED is working
  bool check(){
    if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) { 
        return false;
      }
    else 
        return true;
  }

  void start(){
    // display the startup screen
    display.clearDisplay(); 
    // display world icon 
    display.drawBitmap(0, 0, graphics::world_image, 62, 64, 1);
    // add 'Setting up" text and empty bar
    display.setTextSize(1);
    display.setTextColor(WHITE);        // Set items displayed to be white
    display.setCursor(63, 3);
    display.print("Setting up");
    display.drawRect(56, 49, 58, 12, 1);
    display.display();
    }

  // Fill the bar graph to the length sent
  void fill(int length){
    display.fillRect(57,50, length * 8, 10, 1 );
    display.display();
  }  
  // show thumb up
  void thumb(){
    display.drawBitmap(83, 21, graphics::thumb_image, 16, 16, 1);
    display.display();
  }
   // shows satellite icon and "Finding Sataellites"
   void search(){
    display.clearDisplay(); 
    // display satellite icon 
    display.drawBitmap(0, 0, graphics::satellite_image, 62, 64, 1);
    // display text "Finding Satellites"
    display.setTextColor(WHITE);        
    display.setCursor(63, 3);
    display.print("Finding");
    display.setCursor(63, 12);
    display.print("Satellites");
    display.display();
   }
   // show number of satellites found in large font
   void satNumber(int number){
    // remove previous value using black rectangle for 2 digits
    display.fillRect(82, 24, 28, 18, BLACK);
    display.setTextSize(2);
    display.setTextColor(WHITE);        
    display.setCursor(85, 26);
    display.print(String(number));
    display.display();
   }
   // show Satellite waiting bar graph
   void waiting(int length){
    display.drawRect(60, 49, 62, 12, 1);
    display.fillRect(61,50, length, 10, WHITE );
    display.display();
   }
   // clear Satellite waiting bar graph
   void waitingClear(){
    display.fillRect(61,50, 60, 10, BLACK);
   }

   // Clear area then send "No GPS found. Check antenna and location"
   void noGPS(){
    // clear the area first
    display.fillRect(51, 24, 77, 38, BLACK);
    display.setTextSize(1);
    display.setTextColor(WHITE); 
    display.setCursor(48, 29);
    display.print("Not enough!");
    display.setCursor(48, 39);
    display.print("Check antenna");
    display.setCursor(48, 50);
    display.print("and location");
    display.display();
   }

  // clear the  No GPS message
   void noGPSClear(){
      display.fillRect(48, 24, 77, 38, BLACK);
   }
   
  // Shows the Clock, locked icon, Vc 'v', C,  and # of satellites
   void clock(){
    display.clearDisplay(); 
    // draw the lock icon
   // display.drawBitmap(3, 45, graphics::locked_image, 13, 16, 1);
    display.setTextColor(WHITE);
    display.setTextSize(1);
  //  display.setTextWrap(false);
    display.setCursor(55, 7);
    display.print("UTC");           // display UTC
    display.setTextSize(2);
    display.setCursor(17, 18);
    display.print("00:00:00");      // display 00:00:00
    display.setTextSize(1);
    display.setCursor(101, 2);
    display.print("20");            // display starting temperature
    display.setCursor(83, 53);
    display.print("Sats");          // display Sats
    display.setCursor(22, 2);
    display.print("v");             // display v
    display.display();
   }

  // Sets the clock time
  void time(String time){
    // clear current time
    display.fillRect(15, 16, 98, 19, BLACK);
    display.setTextSize(2);
    display.setCursor(17, 18);
    display.print(time);
    display.display();
  }

  // Displays number of satellites bottom RHS
  void numberSats(int number){
    // clear current number
    display.fillRect(107, 52, 15, 9, BLACK);
    display.setCursor(109, 53);
    display.setTextSize(1);
    display.print(String (number));
    display.display();
  }

    // show error screen
  void error(){
    display.clearDisplay();
    display.setTextColor(WHITE);
    display.setTextSize(1);
    display.setCursor(5, 2);
    display.print("Error!");
    display.setCursor(5, 13);
    display.print("Can't access GPS");
    display.setCursor(5, 25);
    display.print("Serial Port.");
    display.setCursor(6, 37);
    display.print("Try power recycle.");
    display.display();
  }

  // show Vc
  void volts(String vs){
    display.setTextSize(1);
    display.fillRect(2,1,19,10, BLACK);    // clear any previous data
    display.setCursor(2, 2);
    display.print(vs);                     // display the Vc voltage
    display.display();
  }

  // show Pico temperature
  void temp(String temp){
    display.setTextSize(1);
    display.fillRect(100,2,111,9, BLACK);
    display.setCursor(100, 2);
    display.drawCircle(115, 2, 2, WHITE);   // draw a small circle before the C
    display.setCursor(119, 2);
    display.print("C");
    display.setCursor(101, 2);
    display.print(temp);                    // display the temperature
    display.display();
    }

  // show lock with either cross or not
  void showLock(bool cross){
    // clear the current lock
    display.fillRect(3,45,17,62, BLACK);
    // show the lock
    display.drawBitmap(3, 45, graphics::locked_image, 13, 16, 1);
    // if cross false then show it
    if (cross){
      display.drawLine(15,45,3,61, WHITE);
      display.drawLine(3,45,16,61, WHITE);
    }
    display.display();
  }

}