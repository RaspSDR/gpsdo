// Sends data to the GPS and checks for an acknowledgement. 

#pragma once

#include "getUBX_ACK.h"


namespace SendUBX 
{
    bool ackBack = false;    
    // tries sending UBX data 5 times and if acked within 1 second returns true else false
    bool sendUBXBuf(uint8_t *MSG, uint8_t len){
    for (int x = 0; x < 5; x++){
        for(int i=0; i<len; i++) {
            Serial1.write(MSG[i]);
          }
        ackBack = getUBX_ACK::get_ACK(MSG);   // look for ACK
        if (ackBack == true)
            return true;                      // returns true after 1 seconds max
        Serial.print("Trying times = ");
        Serial.println(x);
       }
       return false;  // tried 5 times and failed 
    } 
}