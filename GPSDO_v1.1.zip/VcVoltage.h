/*
  Reads voltage from ADC0 which is the OCXO control voltage divided by 0.66
   5.0 v = 4095  hence calibration is  5.0/4095 = 0.001221

  If Vc < x or > x then padlock is shown with an X over it 
  since the PLL will not be locked.
  
  Averages every second and returns as a string containing Vc.

*/

#pragma once

float Vc = 500.00;
float previous = 0.0;
float actual = 0.00;
bool Xon = true;
bool on = true;
bool off = false;
int x = 0;

namespace VcVoltage
{
  String volts()
  {
    Vc = Vc + 0.3 * (analogRead(A0) - previous);
    // determine if locked
    if (Vc > previous + 80 || Vc < previous - 80){
       if (!Xon){                    
         OLED::showLock(on);                      // Show the lock with a X on it.
         Xon = on;
       }
    }
    else 
      if (Xon){
        x++;
        if (x > 2){                               // wait until we have been locked for 3 seconds
          Xon = false;
          OLED::showLock(off);                    // Show the lock normal after 3 
          Xon = off;
          x = 0;
        }
      }
    previous = Vc;
    actual = Vc * 0.001221;
    return String(actual,1);    // only use 1 decimal point
  }
}