// Checks that data sent to the GPS is received and returns true or false.


#pragma once

namespace getUBX_ACK
{
    // Calculate expected UBX ACK packet and parse UBX response from GPS 
    bool get_ACK(uint8_t *MSG) {
      uint8_t b;
      uint8_t ackByteID = 0;
      unsigned long startTime = millis();
    //  Serial.println();
      Serial.print("  ACK response: ");
    //  Serial.println();
      // Construct the expected ACK packet
      // header,header,class,id,length,0,ACK class,ACK ID,CK_A,CK_B  
      uint8_t ackPacket[10] = {0xB5,0x62,0x05,0x01,0x02,0x00,MSG[2],MSG[3],0,0};
      // Calculate the checksums
      for (uint8_t i=2; i<8; i++) {
        ackPacket[8] = ackPacket[8] + ackPacket[i];
        ackPacket[9] = ackPacket[9] + ackPacket[8];
      }
       
      while (1) { 
        // Test for success
        if (ackByteID > 9) {
          // All packets in order!
          Serial.println("OK!");
          return true;
        }
    
        // Timeout if no valid response in 1 second
        if (millis() - startTime > 1000) { 
          Serial.println("FAILED!- Trying Again");
          return false;
        }
    
        // Make sure GPS data is available to read
        if (Serial1.available()) {
          b = Serial1.read();    
          // Check that bytes arrive in sequence as per expected ACK packet
          if (b == ackPacket[ackByteID]) { 
            ackByteID++;
          } 
        }
      }
    } 
}