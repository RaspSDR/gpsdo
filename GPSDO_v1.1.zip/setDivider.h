// This code sets up the Pico PWM to divide the 10 MHz clock on GPIO 15 by 100 and outputs on GPIO 14.

#pragma once


namespace setDivider
{
   void set(int outPin, int inPin)
   {
        // Set GPIO14 pin to PWM output (channel A)
        gpio_set_function(outPin, GPIO_FUNC_PWM);
        // Set GPIO15 pin to PWM input (channel B)
        gpio_set_function(inPin, GPIO_FUNC_PWM);
        // Get the PWM slice for the pin
        uint slice_num = pwm_gpio_to_slice_num(outPin);   // This is the output pin number
        // Enable PWM
        pwm_set_enabled(slice_num, true);
        // Set Channel B be the PWM counter clock
        pwm_set_clkdiv_mode(slice_num, PWM_DIV_B_RISING); 
        // Set clock divider 
        pwm_set_clkdiv_int_frac(slice_num, 10, 0);    
        // Set counter maximum value before wrap
        pwm_set_wrap(slice_num, 9);
        // Set pulse length in ref clock cycles after division 
        pwm_set_chan_level(slice_num, PWM_CHAN_A, 5);
   }  
}