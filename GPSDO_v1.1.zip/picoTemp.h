// Reads the average temperature of the Pico and returns as a string.

#pragma once


namespace picoTemp
{
  float Temp;
  float tempNow = 25;
  float previous = 0;
  float adcVoltage;

  String get(){
    adc_init();
    adc_set_temp_sensor_enabled(true);
    adc_select_input(4);
    adcVoltage = float(adc_read()) * 3.3f/4095;
    Temp =  27 - (adcVoltage - 0.706) / 0.001721f;  
    tempNow = tempNow + 0.1 * (Temp - previous); // average temp
    previous = tempNow;
    return String(tempNow,0);   // convert to a string with no decimal places
  }
}