// Configures the NeoPixel chip and displays selected colours.

#pragma once

#include <Adafruit_NeoPixel.h>

const int PIN = 16;  // NeoPixel

Adafruit_NeoPixel pixels(1, PIN, NEO_GRB + NEO_KHZ800);

namespace setLED
{
   void begin()
   { 
      pixels.begin();   // INITIALIZE NeoPixel
   }

   void clear()
   {
      pixels.clear(); // set pixel colours to 'off'
      pixels.show();
   }

  void set(String colour)
  {
      if (colour == "white")
        pixels.setPixelColor(0, pixels.Color(255, 255, 255)); 
      else if (colour == "red")
        pixels.setPixelColor(0, pixels.Color(0, 255, 0)); 
      else if (colour == "green")
        pixels.setPixelColor(0, pixels.Color(80, 0, 0));
      else if (colour == "blue")
        pixels.setPixelColor(0, pixels.Color(0, 0, 255));

     pixels.show();
  }
 
}